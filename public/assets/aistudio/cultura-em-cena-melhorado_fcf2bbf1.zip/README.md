<div align="center">
<img width="1200" height="475" alt="GHBanner" src="https://ai.google.dev/static/site-assets/images/share-ais-513315318.png" />
</div>

# Run and deploy your AI Studio app

This contains everything you need to run your app locally.

View your app in AI Studio: https://ai.studio/apps/1d80eb20-fe56-488d-a93e-22e630347b42

## Run Locally

**Prerequisites:**  Node.js


1. Install dependencies:
   `npm install`
2. Set the `GEMINI_API_KEY` in [.env.local](.env.local) to your Gemini API key
3. Run the app:
   `npm run dev`


## Configuração e limites desta versão

- **Dados:** os 12 editais do catálogo são **modelos educativos** (fictícios). O edital do Lucas é baseado no Edital 024/2025 de Indaiatuba (encerrado). O Calendário traz só informações conferidas em 14/10/2026, com fonte e data de verificação; o que não foi confirmado aparece como "A confirmar".
- **WhatsApp:** defina `VITE_WHATSAPP_NUMBER` (DDI + DDD + número, ex.: `5519...`). Sem número, o botão mostra um aviso.
- **Assistente (Gemini):** defina `GEMINI_API_KEY` no servidor. A chave nunca vai para o navegador. Há limite de 20 perguntas por 10 minutos por visitante.
- **Google Workspace:** o login pede apenas escopos mínimos (arquivos criados pelo app, eventos de agenda e formulários). Ao publicar para o público, o Google pode exigir verificação do app.
- **Aviso de movimento:** a mensagem "Reduced Motion enabled" do console aparece quando o sistema do visitante pede menos animação. Ela é esperada e não é um erro.
