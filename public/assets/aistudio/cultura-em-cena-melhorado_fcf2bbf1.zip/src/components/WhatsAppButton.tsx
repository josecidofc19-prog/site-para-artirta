import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence, useReducedMotion } from 'framer-motion';
import { AlertCircle, X } from 'lucide-react';
import { WHATSAPP_NUMBER, WHATSAPP_DEFAULT_MESSAGE } from '../config/whatsapp';
import { useApp } from '../context/AppContext';

export const WhatsAppButton: React.FC = () => {
  const { showToast } = useApp();
  const [showNotice, setShowNotice] = useState(false);
  const shouldReduceMotion = useReducedMotion();

  const cleanNumber = WHATSAPP_NUMBER.trim().replace(/\D/g, '');
  const isConfigured = cleanNumber.length >= 8;

  useEffect(() => {
    if (!showNotice) return;
    const timer = setTimeout(() => setShowNotice(false), 4500);
    return () => clearTimeout(timer);
  }, [showNotice]);

  const handleUnconfiguredClick = (e: React.MouseEvent) => {
    e.preventDefault();
    setShowNotice(true);
    showToast(
      'WhatsApp',
      'Contato por WhatsApp ainda não configurado',
      'info'
    );
  };

  const whatsappUrl = isConfigured
    ? `https://wa.me/${cleanNumber}?text=${encodeURIComponent(WHATSAPP_DEFAULT_MESSAGE)}`
    : undefined;

  return (
    <div className="fixed bottom-5 sm:bottom-6 right-4 sm:right-6 z-40 flex flex-col items-end pointer-events-none">
      {/* Aviso amigável quando o número não está configurado */}
      <AnimatePresence>
        {showNotice && (
          <motion.div
            initial={shouldReduceMotion ? { opacity: 0 } : { opacity: 0, y: 8, scale: 0.95 }}
            animate={shouldReduceMotion ? { opacity: 1 } : { opacity: 1, y: 0, scale: 1 }}
            exit={shouldReduceMotion ? { opacity: 0 } : { opacity: 0, y: 6, scale: 0.95 }}
            transition={{ duration: 0.2 }}
            role="alert"
            className="mb-2.5 max-w-xs sm:max-w-sm p-3.5 rounded-2xl bg-slate-900 text-white dark:bg-slate-800 dark:border dark:border-white/10 shadow-xl pointer-events-auto flex items-start gap-2.5 text-xs border border-slate-700"
          >
            <AlertCircle className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" aria-hidden="true" />
            <div className="flex-1 pr-1">
              <p className="font-semibold text-slate-100 mb-0.5">Atendimento em implantação</p>
              <p className="text-slate-300 leading-relaxed">
                Contato por WhatsApp ainda não configurado.
              </p>
            </div>
            <button
              onClick={() => setShowNotice(false)}
              className="text-slate-400 hover:text-white p-1 rounded-lg focus:outline-none focus-visible:ring-2 focus-visible:ring-emerald-400 cursor-pointer"
              aria-label="Fechar aviso de WhatsApp"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Botão Flutuante */}
      {isConfigured ? (
        <motion.a
          href={whatsappUrl}
          target="_blank"
          rel="noopener noreferrer"
          aria-label="Falar com a equipe pelo WhatsApp"
          whileHover={shouldReduceMotion ? undefined : { y: -2, scale: 1.02 }}
          whileTap={shouldReduceMotion ? undefined : { scale: 0.96 }}
          className="pointer-events-auto group inline-flex items-center gap-2.5 p-3 sm:px-4 sm:py-3 rounded-full bg-emerald-600 hover:bg-emerald-700 text-white font-semibold text-xs sm:text-sm shadow-lg shadow-emerald-950/20 dark:shadow-black/50 border border-emerald-500/30 transition-colors focus:outline-none focus-visible:ring-2 focus-visible:ring-emerald-500 focus-visible:ring-offset-2 dark:focus-visible:ring-offset-slate-950 cursor-pointer"
        >
          <WhatsAppIcon className="w-5 h-5 fill-current shrink-0" />
          <span className="tracking-tight whitespace-nowrap hidden sm:inline">Fale com a gente</span>
        </motion.a>
      ) : (
        <motion.button
          type="button"
          onClick={handleUnconfiguredClick}
          aria-label="Falar com a equipe pelo WhatsApp"
          whileHover={shouldReduceMotion ? undefined : { y: -2, scale: 1.02 }}
          whileTap={shouldReduceMotion ? undefined : { scale: 0.96 }}
          className="pointer-events-auto group inline-flex items-center gap-2.5 p-3 sm:px-4 sm:py-3 rounded-full bg-emerald-600 hover:bg-emerald-700 text-white font-semibold text-xs sm:text-sm shadow-lg shadow-emerald-950/20 dark:shadow-black/50 border border-emerald-500/30 transition-colors focus:outline-none focus-visible:ring-2 focus-visible:ring-emerald-500 focus-visible:ring-offset-2 dark:focus-visible:ring-offset-slate-950 cursor-pointer"
        >
          <WhatsAppIcon className="w-5 h-5 fill-current shrink-0" />
          <span className="tracking-tight whitespace-nowrap hidden sm:inline">Fale com a gente</span>
        </motion.button>
      )}
    </div>
  );
};

const WhatsAppIcon: React.FC<{ className?: string }> = ({ className }) => (
  <svg
    viewBox="0 0 24 24"
    className={className}
    aria-hidden="true"
    focusable="false"
  >
    <path d="M.057 24l1.687-6.163c-1.041-1.804-1.588-3.849-1.587-5.946.003-6.556 5.338-11.891 11.893-11.891 3.181.001 6.167 1.24 8.413 3.488 2.245 2.248 3.481 5.236 3.48 8.414-.003 6.557-5.338 11.892-11.893 11.892-1.99-.001-3.951-.5-5.688-1.448l-6.305 1.654zm6.597-3.807c1.676.995 3.276 1.591 5.392 1.592 5.448 0 9.886-4.434 9.889-9.885.002-5.462-4.415-9.89-9.881-9.892-5.452 0-9.887 4.434-9.889 9.884-.001 2.225.651 3.891 1.746 5.634l-.999 3.648 3.742-.983zm11.387-5.464c-.074-.124-.272-.198-.57-.347-.297-.149-1.758-.868-2.031-.967-.272-.099-.47-.149-.669.149-.198.297-.768.967-.941 1.165-.173.198-.347.223-.644.074-.297-.149-1.255-.462-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.297-.347.446-.521.151-.172.2-.296.3-.495.099-.198.05-.372-.025-.521-.075-.148-.669-1.611-.916-2.206-.242-.579-.487-.501-.669-.51l-.57-.01c-.198 0-.52.074-.792.372s-1.04 1.016-1.04 2.479 1.065 2.876 1.213 3.074c.149.198 2.095 3.2 5.076 4.487.709.306 1.263.489 1.694.626.712.226 1.36.194 1.872.118.571-.085 1.758-.719 2.006-1.413.248-.695.248-1.29.173-1.414z" />
  </svg>
);
