import React, { Suspense, lazy } from 'react';
import { MotionConfig } from 'framer-motion';
import { AppProvider, useApp } from './context/AppContext';
import { BannerAviso } from './components/BannerAviso';
import { Navbar } from './components/Navbar';
import { Footer } from './components/Footer';
import { WhatsAppButton } from './components/WhatsAppButton';
import { CulturalAssistant } from './components/CulturalAssistant';
import { PrepChoiceModal } from './components/PrepChoiceModal';
import { AuthModal } from './components/AuthModal';
import { ToastNotification } from './components/ToastNotification';
import { WorkspaceHub } from './components/WorkspaceHub';

const WorkspaceModalRenderer: React.FC = () => {
  const { workspaceModalOpen, setWorkspaceModalOpen } = useApp();
  return <WorkspaceHub isOpen={workspaceModalOpen} onClose={() => setWorkspaceModalOpen(false)} />;
};


// As páginas são carregadas sob demanda para reduzir o bundle inicial.
const HomePage = lazy(() => import('./components/HomePage').then(m => ({ default: m.HomePage })));
const CatalogPage = lazy(() => import('./components/CatalogPage').then(m => ({ default: m.CatalogPage })));
const GrantDetailPage = lazy(() => import('./components/GrantDetailPage').then(m => ({ default: m.GrantDetailPage })));
const VaultPage = lazy(() => import('./components/VaultPage').then(m => ({ default: m.VaultPage })));
const ChecklistPage = lazy(() => import('./components/ChecklistPage').then(m => ({ default: m.ChecklistPage })));
const PerformanceDashboard = lazy(() => import('./components/PerformanceDashboard').then(m => ({ default: m.PerformanceDashboard })));
const GuiaArtistaPage = lazy(() => import('./components/GuiaArtistaPage').then(m => ({ default: m.GuiaArtistaPage })));
const ApoioArtistaPage = lazy(() => import('./components/ApoioArtistaPage').then(m => ({ default: m.ApoioArtistaPage })));
const ComoFuncionaPage = lazy(() => import('./components/ComoFuncionaPage').then(m => ({ default: m.ComoFuncionaPage })));
const FormularioProjetoPage = lazy(() => import('./components/FormularioProjetoPage').then(m => ({ default: m.FormularioProjetoPage })));
const PerfilConfigPage = lazy(() => import('./components/PerfilConfigPage').then(m => ({ default: m.PerfilConfigPage })));
const CalendarioCulturalPage = lazy(() => import('./components/CalendarioCulturalPage').then(m => ({ default: m.CalendarioCulturalPage })));
const EmpresasPage = lazy(() => import('./components/EmpresasPage').then(m => ({ default: m.EmpresasPage })));
const OrganizacoesPublicasPage = lazy(() => import('./components/OrganizacoesPublicasPage').then(m => ({ default: m.OrganizacoesPublicasPage })));

const PageFallback: React.FC = () => (
  <div className="flex min-h-[60vh] flex-col items-center justify-center space-y-4" role="status" aria-live="polite" aria-label="Carregando página">
    <div className="h-10 w-10 rounded-full border-4 border-[#E6E0D5] border-t-[#991B1B] dark:border-white/10 dark:border-t-[#e4806f] motion-safe:animate-spin motion-reduce:animate-none" />
    <p className="text-xs font-medium uppercase tracking-wider text-[#78716C] dark:text-[#A8A29E]">Carregando página...</p>
  </div>
);

const MainContent: React.FC = () => {
  const { currentView } = useApp();

  return (
    <main className="min-h-[calc(100vh-140px)]">
      <Suspense fallback={<PageFallback />}>
        {currentView === 'home' && <HomePage />}
        {currentView === 'catalog' && <CatalogPage />}
        {currentView === 'calendario' && <CalendarioCulturalPage />}
        {currentView === 'grant_detail' && <GrantDetailPage />}
        {currentView === 'vault' && <VaultPage />}
        {currentView === 'checklist' && <ChecklistPage />}
        {currentView === 'dashboard' && <PerformanceDashboard />}
        {currentView === 'guia' && <GuiaArtistaPage />}
        {currentView === 'apoio' && <ApoioArtistaPage />}
        {currentView === 'como_funciona' && <ComoFuncionaPage />}
        {currentView === 'formulario_projeto' && <FormularioProjetoPage />}
        {currentView === 'perfil' && <PerfilConfigPage />}
        {currentView === 'empresas' && <EmpresasPage />}
        {currentView === 'organizacoes_publicas' && <OrganizacoesPublicasPage />}
      </Suspense>
    </main>
  );
};

export default function App() {
  return (
    <MotionConfig reducedMotion="user">
      <AppProvider>
        <div className="min-h-screen flex flex-col bg-[#faf7f2] dark:bg-[#121214] text-[#1c1917] dark:text-[#f5f3ef] transition-colors">
          {/* Banner de Aviso Acadêmico e Ações de Demonstração */}
          <BannerAviso />

          {/* Barra de Navegação Superior */}
          <Navbar />

          {/* Conteúdo Principal com Troca de Telas */}
          <div className="flex-1">
            <MainContent />
          </div>

          {/* Rodapé Global Estruturado */}
          <Footer />

          {/* Botão Flutuante do Assistente Cultural (acima do WhatsApp) */}
          <CulturalAssistant />

          {/* Botão Flutuante de Atendimento WhatsApp */}
          <WhatsAppButton />

          {/* Modais Globais e Notificações Flutuantes */}
          <PrepChoiceModal />
          <AuthModal />
          <WorkspaceModalRenderer />
          <ToastNotification />
        </div>
      </AppProvider>
    </MotionConfig>
  );
}
