import { Grant, ArtistProfileType, ArtisticArea, Sphere } from '../types';

/**
 * Utilitário para gerar datas relativas precisas baseadas na data atual da execução.
 */
function getDateOffset(days: number): string {
  const now = new Date();
  const target = new Date(now.getFullYear(), now.getMonth(), now.getDate() + days, 23, 59, 59);
  return target.toISOString();
}

function getPastDateOffset(days: number): string {
  const now = new Date();
  const target = new Date(now.getFullYear(), now.getMonth(), now.getDate() - days, 18, 0, 0);
  return target.toISOString();
}

export const FICTITIOUS_NOTICE = "Modelo educativo: conteúdo fictício criado para treinar o uso da plataforma, inspirado em tipos de editais reais. Órgãos, valores, prazos e regras deste cartão não são oficiais e não representam uma inscrição aberta. Confira sempre o edital oficial.";

/**
 * Interface para os eventos do Calendário Cultural Anual (Previsões e Ciclos Regulares)
 */
export interface AnnualCalendarForecast {
  id: string;
  title: string;
  issuingBody: string;
  sphere: Sphere;
  city?: string;
  state: string;
  artisticArea: ArtisticArea;
  annualQuarter: 'Q1' | 'Q2' | 'Q3' | 'Q4';
  cyclePeriod: string; // Ex: "Março a Maio"
  status: 'aberto' | 'previsao' | 'encerrado' | 'a_confirmar';
  estimatedGrantValue: string;
  officialUrl: string;
  description: string;
  recommendedPrepDocs: string[];
  tipsForArtist: string;
  linkedGrantId?: string;
  verifiedAt?: string; // dd/mm/aaaa: quando a fonte foi conferida
  sourceNote?: string; // observação sobre a fonte
}

/**
 * Calendário cultural anual consolidado com previsões e janelas estimadas
 */
export const ANNUAL_CALENDAR_FORECASTS: AnnualCalendarForecast[] = [
  {
    id: 'cal-indaiatuba-credenciamento-musical-024-2025',
    title: 'Credenciamento de Projetos Musicais para Eventos (Edital 024/2025)',
    issuingBody: 'Prefeitura de Indaiatuba — Secretaria Municipal de Cultura',
    sphere: 'Municipal', city: 'Indaiatuba', state: 'SP', artisticArea: 'Música',
    annualQuarter: 'Q3',
    cyclePeriod: 'Abril de 2025 a 31/07/2026',
    status: 'encerrado',
    estimatedGrantValue: 'Cachê bruto: R$ 825 (solo) a R$ 4.125 (5 integrantes), + R$ 825 por integrante extra',
    officialUrl: 'https://www.indaiatuba.sp.gov.br/cultura/arquivos/doc_edital_20250403110746_chamamento-04-25.pdf',
    description: 'Credenciava solos, duos, trios, quartetos e grandes grupos para os eventos da Prefeitura, com inscrição contínua. Estar habilitado não garantia contratação: a Secretaria convocava conforme a programação.',
    recommendedPrepDocs: [
      'Situação cadastral do CNPJ',
      'Certidão de débitos federais e Dívida Ativa da União',
      'Certidão negativa de débitos municipais',
      'Certificado de Regularidade do FGTS (CRF)',
      'Certidão negativa de débitos trabalhistas (CNDT)',
      'Alvará municipal ou CCMEI',
    ],
    tipsForArtist: 'Foi a base do edital-modelo da demonstração. Na próxima abertura, grupos com a maioria (50% + 1) dos integrantes residentes em Indaiatuba ganharam pontuação extra.',
    linkedGrantId: 'edital-circulacao-musical-sp',
    verifiedAt: '14/10/2026',
    sourceNote: 'Edital em PDF e portal da Secretaria de Cultura',
  },
  {
    id: 'cal-indaiatuba-patrocinio-eventos-2026',
    title: 'Chamamento para Patrocínio de Eventos de Cultura 2026 (Edital 017/2026)',
    issuingBody: 'Prefeitura de Indaiatuba — Secretaria Municipal de Cultura',
    sphere: 'Municipal', city: 'Indaiatuba', state: 'SP', artisticArea: 'Música',
    annualQuarter: 'Q4',
    cyclePeriod: 'Até 11/12/2026',
    status: 'aberto',
    estimatedGrantValue: 'Valor não informado',
    officialUrl: 'https://cultura.indaiatuba.sp.gov.br/editais/',
    description: 'Seleciona propostas de patrocínio para eventos culturais e turísticos de 2026. É voltado a pessoas jurídicas que patrocinam eventos, não é um apoio direto a artistas.',
    recommendedPrepDocs: [
      'CNPJ e contrato social ou documento constitutivo atualizado',
      'Regularidade federal e municipal, FGTS e CNDT',
      'Proposta formal em papel timbrado, identificando o evento',
    ],
    tipsForArtist: 'Artistas podem se aproximar de empresas interessadas em patrocinar eventos musicais e propor uma parceria.',
    verifiedAt: '14/10/2026',
    sourceNote: 'Situação lida no portal da Secretaria de Cultura',
  },
  {
    id: 'cal-indaiatuba-oficineiros',
    title: 'Credenciamento de Oficineiros e Oficinas Artísticas e Culturais',
    issuingBody: 'Prefeitura de Indaiatuba — Secretaria Municipal de Cultura',
    sphere: 'Municipal', city: 'Indaiatuba', state: 'SP', artisticArea: 'Música',
    annualQuarter: 'Q4',
    cyclePeriod: 'Vigência até 18/11/2030',
    status: 'aberto',
    estimatedGrantValue: 'Valor não informado',
    officialUrl: 'https://cultura.indaiatuba.sp.gov.br/editais/',
    description: 'Credenciamento contínuo para ministrar oficinas. A contratação ocorre por demanda da Secretaria, sem garantia de convocação.',
    recommendedPrepDocs: ['Veja a lista completa de documentos no edital oficial'],
    tipsForArtist: 'Serve para músicos que também ensinam. Não é um edital de apoio a shows.',
    verifiedAt: '14/10/2026',
    sourceNote: 'Situação lida no portal da Secretaria de Cultura',
  },
  {
    id: 'cal-indaiatuba-criarte',
    title: 'Credenciamento do Programa de Qualificação em Economia Criativa (CRIARTE)',
    issuingBody: 'Prefeitura de Indaiatuba — Secretaria de Cultura e Espaço CRIARTE',
    sphere: 'Municipal', city: 'Indaiatuba', state: 'SP', artisticArea: 'Música',
    annualQuarter: 'Q3',
    cyclePeriod: 'Vigência até 23/07/2030',
    status: 'aberto',
    estimatedGrantValue: 'Valor não informado',
    officialUrl: 'https://cultura.indaiatuba.sp.gov.br/editais/',
    description: 'Forma um cadastro de pessoas jurídicas (inclui MEI) aptas a conduzir cursos e oficinas do programa de economia criativa.',
    recommendedPrepDocs: [
      'CNPJ ativo com CNAE compatível',
      'Contrato social, requerimento de empresário ou CCMEI',
      'Certidões federal, estadual e municipal, CRF do FGTS e CNDT',
      'Conta bancária em nome da pessoa jurídica',
    ],
    tipsForArtist: 'Útil para quem quer oferecer formação em produção e divulgação musical.',
    verifiedAt: '14/10/2026',
    sourceNote: 'Edital e portal da Secretaria de Cultura',
  },
  {
    id: 'cal-indaiatuba-rock-2026',
    title: 'Festival de Rock de Indaiatuba 2026',
    issuingBody: 'Prefeitura de Indaiatuba — Secretaria Municipal de Cultura',
    sphere: 'Municipal', city: 'Indaiatuba', state: 'SP', artisticArea: 'Música',
    annualQuarter: 'Q3',
    cyclePeriod: '30/06 a 30/07/2026 (final em 07 e 08/11/2026)',
    status: 'encerrado',
    estimatedGrantValue: 'Valor não informado',
    officialUrl: 'https://www.indaiatuba.sp.gov.br/cultura/arquivos/doc_edital_20260623100629_edital-de-rock-2026.pdf',
    description: 'Festival de rock. Aceitava artistas solo, duplas ou bandas de qualquer cidade.',
    recommendedPrepDocs: [
      'Vídeo de inscrição gravado ao vivo e sem cortes',
      'Formulário de inscrição preenchido e assinado pelo responsável',
    ],
    tipsForArtist: 'A janela de inscrição muda de ano para ano: em 2026 abriu em junho. Acompanhe o portal.',
    verifiedAt: '14/10/2026',
    sourceNote: 'Edital em PDF e portal da Secretaria de Cultura',
  },
  {
    id: 'cal-indaiatuba-instrumental-2026',
    title: 'Festival de Música Instrumental de Indaiatuba 2026',
    issuingBody: 'Prefeitura de Indaiatuba — Secretaria Municipal de Cultura',
    sphere: 'Municipal', city: 'Indaiatuba', state: 'SP', artisticArea: 'Música',
    annualQuarter: 'Q2',
    cyclePeriod: '19/05 a 17/06/2026',
    status: 'encerrado',
    estimatedGrantValue: 'Valor não informado',
    officialUrl: 'https://www.indaiatuba.sp.gov.br/cultura/arquivos/doc_edital_20260519120105_edital-femusin.pdf',
    description: 'Festival de música instrumental. Confira no edital oficial as regras, as categorias e a premiação.',
    recommendedPrepDocs: ['Veja a lista completa de documentos no edital oficial'],
    tipsForArtist: 'A janela de inscrição muda de ano para ano. Acompanhe o portal.',
    verifiedAt: '14/10/2026',
    sourceNote: 'Edital em PDF e portal da Secretaria de Cultura',
  },
  {
    id: 'cal-indaiatuba-pnab-2026',
    title: 'PNAB Indaiatuba — Edital de Chamamento PNAB 01/2026',
    issuingBody: 'Prefeitura de Indaiatuba — Secretaria Municipal de Cultura',
    sphere: 'Municipal', city: 'Indaiatuba', state: 'SP', artisticArea: 'Música',
    annualQuarter: 'Q2',
    cyclePeriod: 'Abril a maio de 2026',
    status: 'encerrado',
    estimatedGrantValue: 'Valor não informado',
    officialUrl: 'https://cultura.indaiatuba.sp.gov.br/editais/concluidos/',
    description: 'Seleção de projetos culturais com recursos federais da Política Nacional Aldir Blanc. O portal já publicou o resultado provisório.',
    recommendedPrepDocs: ['Veja a lista completa de documentos no edital oficial'],
    tipsForArtist: 'Os editais da PNAB são publicados pelo município ou pelo Estado, e não por um edital federal único.',
    verifiedAt: '14/10/2026',
    sourceNote: 'Portal da Secretaria de Cultura (editais concluídos)',
  },
  {
    id: 'cal-indaiatuba-maio-musical-previsao',
    title: 'Maio Musical — próxima chamada para artistas',
    issuingBody: 'Prefeitura de Indaiatuba — Secretaria Municipal de Cultura',
    sphere: 'Municipal', city: 'Indaiatuba', state: 'SP', artisticArea: 'Música',
    annualQuarter: 'Q1',
    cyclePeriod: 'Março (histórico: 2023 e 2024)',
    status: 'previsao',
    estimatedGrantValue: 'Valor não informado',
    officialUrl: 'https://cultura.indaiatuba.sp.gov.br/editais/concluidos/',
    description: 'Nos anos de 2023 e 2024 houve chamamento específico em março. O festival de 2026 teve mais de 60 atrações gratuitas e mais de 100 mil pessoas, segundo a imprensa regional.',
    recommendedPrepDocs: [
      'Cofre em dia: certidão federal, municipal, FGTS e CNDT',
      'Portfólio com vídeos de shows ao vivo e links ativos',
    ],
    tipsForArtist: 'Estimativa pelo histórico, não confirmada. Nos chamamentos de 2024, grupos precisavam de ao menos 50% de integrantes residentes na cidade.',
    verifiedAt: '14/10/2026',
    sourceNote: 'Histórico do portal e notícia do Correio da Manhã (Região de Campinas)',
  },
  {
    id: 'cal-indaiatuba-festival-verao-previsao',
    title: 'Festival de Verão — próxima chamada para artistas',
    issuingBody: 'Prefeitura de Indaiatuba — Secretaria Municipal de Cultura',
    sphere: 'Municipal', city: 'Indaiatuba', state: 'SP', artisticArea: 'Música',
    annualQuarter: 'Q4',
    cyclePeriod: 'Dezembro (histórico: 12 a 21/12/2023)',
    status: 'previsao',
    estimatedGrantValue: 'Valor não informado',
    officialUrl: 'https://cultura.indaiatuba.sp.gov.br/editais/concluidos/',
    description: 'O portal registra um credenciamento de projetos musicais para o Festival de Verão de 2024, com inscrições em dezembro de 2023.',
    recommendedPrepDocs: ['Cofre em dia: certidões e portfólio atualizados'],
    tipsForArtist: 'Estimativa pelo histórico, não confirmada. Não encontrei chamada para 2026/2027 no portal em 14/10/2026.',
    verifiedAt: '14/10/2026',
    sourceNote: 'Histórico do portal da Secretaria de Cultura',
  },
  {
    id: 'cal-indaiatuba-carnaval-previsao',
    title: 'Carnaval de Rua de Indaiatuba — próxima chamada para artistas',
    issuingBody: 'Prefeitura de Indaiatuba — Secretaria Municipal de Cultura',
    sphere: 'Municipal', city: 'Indaiatuba', state: 'SP', artisticArea: 'Música',
    annualQuarter: 'Q1',
    cyclePeriod: 'Janeiro a fevereiro (histórico: 2024 e 2025)',
    status: 'previsao',
    estimatedGrantValue: 'Valor não informado',
    officialUrl: 'https://cultura.indaiatuba.sp.gov.br/editais/concluidos/',
    description: 'Credenciamento de projetos musicais para o Carnaval de Rua, com inscrições de 08 a 22/01/2024 e de 30/01 a 10/02/2025.',
    recommendedPrepDocs: ['Cofre em dia: certidões e portfólio atualizados'],
    tipsForArtist: 'Estimativa pelo histórico, não confirmada. As datas mudam de ano para ano.',
    verifiedAt: '14/10/2026',
    sourceNote: 'Histórico do portal da Secretaria de Cultura',
  },
  {
    id: 'cal-campinas-ficc-2026',
    title: 'FICC Campinas 2026 — Fundo de Investimentos Culturais',
    issuingBody: 'Prefeitura de Campinas — Secretaria Municipal de Cultura e Turismo',
    sphere: 'Municipal', city: 'Campinas', state: 'SP', artisticArea: 'Música',
    annualQuarter: 'Q3',
    cyclePeriod: '01/07 a 31/07/2026',
    status: 'encerrado',
    estimatedGrantValue: 'Valor não informado',
    officialUrl: 'https://portal-adm.campinas.sp.gov.br/sites/default/files/anexos_avulsos/edital_1.pdf',
    description: 'Edital de financiamento de projetos culturais, incluindo música. Exigia proponente residente em Campinas há pelo menos 2 anos.',
    recommendedPrepDocs: ['Comprovação de residência em Campinas há pelo menos 2 anos'],
    tipsForArtist: 'Artistas de outras cidades da região, como Indaiatuba, não eram elegíveis.',
    verifiedAt: '14/10/2026',
    sourceNote: 'Edital em PDF no portal da Prefeitura de Campinas',
  },
  {
    id: 'cal-jundiai-festival-musica-2026',
    title: '5º Festival de Música de Jundiaí 2026',
    issuingBody: 'Prefeitura de Jundiaí — Secretaria Municipal de Cultura',
    sphere: 'Municipal', city: 'Jundiaí', state: 'SP', artisticArea: 'Música',
    annualQuarter: 'Q3',
    cyclePeriod: '15/06 a 31/07/2026 (apresentações de 01 a 04/10/2026)',
    status: 'encerrado',
    estimatedGrantValue: 'Valor não informado',
    officialUrl: 'https://cultura.jundiai.sp.gov.br/wp-content/uploads/2026/06/Edital-5o-Festival-de-Musica-de-Jundiai-2026.docx.pdf',
    description: 'Festival de música voltado a artistas de Jundiaí, Louveira e Várzea Paulista, conforme o edital.',
    recommendedPrepDocs: ['Confira no edital a exigência de residência nas três cidades'],
    tipsForArtist: 'Artistas de Indaiatuba não estavam entre as cidades elegíveis.',
    verifiedAt: '14/10/2026',
    sourceNote: 'Edital em PDF no portal da Prefeitura de Jundiaí',
  },
  {
    id: 'cal-sp-fomento-estadual-a-confirmar',
    title: 'Editais estaduais de música (ProAC / Fomento CultSP)',
    issuingBody: 'Secretaria da Cultura, Economia e Indústria Criativas de SP',
    sphere: 'Estadual', state: 'SP', artisticArea: 'Música',
    annualQuarter: 'Q4',
    cyclePeriod: 'A confirmar',
    status: 'a_confirmar',
    estimatedGrantValue: 'Valor não informado',
    officialUrl: 'https://www.cultura.sp.gov.br/',
    description: 'Não consegui confirmar, em 14/10/2026, nenhum edital estadual de música com inscrições abertas. Os editais de apoio a shows costumam ter regras próprias, como sede no Estado há pelo menos 2 anos.',
    recommendedPrepDocs: ['Confira os documentos no edital específico de cada linha'],
    tipsForArtist: 'Consulte o portal da Secretaria antes de planejar uma inscrição.',
    verifiedAt: '14/10/2026',
    sourceNote: 'Não verificado: confirme no site oficial',
  },
  {
    id: 'cal-rouanet-a-confirmar',
    title: 'Lei Rouanet — apresentação de propostas pelo Salic',
    issuingBody: 'Ministério da Cultura',
    sphere: 'Federal', state: 'SP', artisticArea: 'Música',
    annualQuarter: 'Q4',
    cyclePeriod: 'A confirmar',
    status: 'a_confirmar',
    estimatedGrantValue: 'Valor não informado',
    officialUrl: 'https://www.gov.br/pt-br/servicos/obter-autorizacao-para-captacao-de-recursos-via-lei-de-incentivo-a-cultura-a-partir-da-apresentacao-de-proposta-cultural',
    description: 'O proponente cadastra uma proposta no Salic. Se aprovada, ela pode captar recursos com patrocinadores. Não é um repasse direto do governo.',
    recommendedPrepDocs: ['Proposta cultural, orçamento, cronograma e plano de execução'],
    tipsForArtist: 'Confira no portal do Ministério as regras e prazos vigentes.',
    verifiedAt: '14/10/2026',
    sourceNote: 'Não verificado: confirme no site oficial',
  },
];

/**
 * Exatamente 12 editais-modelo (modelos educativos, NÃO são editais oficiais):
 * - 10 abertos (prazos entre 7 e 88 dias)
 * - 2 encerrados (-5 e -20 dias para verificação de filtros)
 */
export function getMockGrants(): Grant[] {
  return [
    // 1. EDITAL-MODELO DO LUCAS: modelo educativo baseado no Edital 024/2025 de Indaiatuba (encerrado). Prazo ilustrativo (+28 dias).
    {
      id: 'edital-circulacao-musical-sp',
      title: 'Credenciamento de Projetos Musicais para Eventos de Indaiatuba (modelo baseado no Edital 024/2025)',
      issuingBody: 'Modelo educativo baseado em edital da Secretaria Municipal de Cultura de Indaiatuba',
      sphere: 'Municipal',
      city: 'Indaiatuba',
      state: 'SP',
      eligibleProfiles: ['banda_grupo', 'artista_solo', 'coletivo_cultural'],
      eligibleLegal: ['mei', 'empresa'],
      artisticArea: 'Música',
      grantValue: 4125,
      totalBudgetFormatted: 'Cachê bruto por apresentação: R$ 825 (solo), R$ 1.650 (dupla), R$ 2.475 (trio), R$ 3.300 (quarteto), R$ 4.125 (5 integrantes) + R$ 825 por integrante extra',
      publishedDate: getPastDateOffset(25),
      deadlineDate: getDateOffset(28), // prazo ilustrativo: no edital real a inscrição era contínua
      summary: 'Modelo educativo: credencia projetos musicais, de solo a grandes grupos, para se apresentar nos eventos da Prefeitura, com cachê por formação e pontuação extra para grupos com a maioria dos integrantes residentes na cidade.',
      description: 'Baseado no Edital 024/2025 de Indaiatuba, encerrado em 31/07/2026. No edital real as inscrições eram contínuas e estar habilitado não garantia contratação: a Secretaria convocava conforme a programação. Aqui o prazo é ilustrativo, para a demonstração. A pontuação real somava 130 pontos, com nota de corte de 65; os percentuais abaixo são aproximados. O projeto musical inclui repertório em PDF, rider técnico, vídeos de shows ao vivo e links ativos até o fim da seleção.',
      objective: 'Habilitar projetos musicais para a programação dos eventos da Prefeitura e fortalecer a cena musical local.',
      eligiblePublic: 'Pessoas jurídicas, incluindo MEI, com finalidade artística ou cultural. Grupos com 50% mais 1 dos integrantes residentes em Indaiatuba recebem pontuação extra, com autodeclaração assinada.',
      restrictions: [
        'Servidores públicos têm restrições para participar. Confira no edital oficial.',
        'Documentação incompleta pode levar ao indeferimento da inscrição.',
        'Não é permitido trocar músicos por subcontratados sem autorização prévia da Secretaria.',
      ],
      evaluationCriteria: [
        { title: 'Adequação ao contexto local (30 pts)', weight: 23, description: 'Como o projeto dialoga com a cultura e as necessidades de Indaiatuba. Nota zero desclassifica.' },
        { title: 'Factibilidade e viabilidade (25 pts)', weight: 19, description: 'Capacidade técnica e operacional (equipamentos, rider) e viabilidade econômica. Nota zero desclassifica.' },
        { title: 'Qualidade técnica (20 pts)', weight: 15, description: 'Competência dos artistas e da produção, avaliada em vídeos de shows ao vivo. Nota zero desclassifica.' },
        { title: 'Integrantes residentes em Indaiatuba (20 pts)', weight: 15, description: 'Maioria (50% + 1) dos integrantes residentes na cidade, com autodeclaração assinada.' },
        { title: 'Experiência e histórico de atuação (15 pts)', weight: 12, description: 'Histórico de apresentações do proponente.' },
        { title: 'Presença digital (10 pts)', weight: 8, description: 'Presença e engajamento do projeto em canais digitais.' },
        { title: 'Atuação local nos últimos 2 anos (10 pts)', weight: 8, description: 'Comprovação de atuação na cidade nos últimos 2 anos.' },
      ],
      requiredDocuments: [
        {
          id: 'doc-req-cnd-federal',
          name: 'Certidão de Débitos Federais e Dívida Ativa da União',
          category: 'financeiro_fiscal',
          mandatory: true,
          appliesToProfiles: ['banda_grupo', 'artista_solo', 'coletivo_cultural', 'produtor_cultural'],
          description: 'Exigida para a habilitação. Em geral vale por cerca de 180 dias; confira a validade na emissão.',
        },
        {
          id: 'doc-req-fgts',
          name: 'Certificado de Regularidade do FGTS (CRF)',
          category: 'financeiro_fiscal',
          mandatory: true,
          appliesToProfiles: ['banda_grupo', 'artista_solo', 'coletivo_cultural', 'produtor_cultural'],
          description: 'Exigido para a habilitação. Em geral vale por cerca de 30 dias; confira a validade na emissão.',
        },
        {
          id: 'doc-req-residencia',
          name: 'Comprovante de Residência dos Integrantes (Indaiatuba)',
          category: 'identificacao',
          mandatory: true,
          appliesToProfiles: ['banda_grupo', 'artista_solo', 'coletivo_cultural', 'produtor_cultural'],
          description: 'Comprova a proporção de integrantes residentes, junto com a autodeclaração (Anexo IV). Use um comprovante recente.',
        },
        {
          id: 'doc-req-portfolio',
          name: 'Portfólio artístico com vídeos de shows ao vivo',
          category: 'artistico',
          mandatory: false,
          appliesToProfiles: ['banda_grupo', 'artista_solo'],
          description: 'Avaliado em qualidade técnica e experiência. Os links precisam ficar ativos até o fim da seleção.',
        },
        {
          id: 'doc-req-cndt',
          name: 'Certidão Negativa de Débitos Trabalhistas (CNDT)',
          category: 'financeiro_fiscal',
          mandatory: false,
          appliesToProfiles: ['banda_grupo', 'artista_solo', 'coletivo_cultural', 'produtor_cultural'],
          description: 'Exigida na contratação, se você for convocado. Prepare com antecedência.',
        },
        {
          id: 'doc-req-cnd-municipal',
          name: 'Certidão Negativa de Débitos Municipais',
          category: 'financeiro_fiscal',
          mandatory: false,
          appliesToProfiles: ['banda_grupo', 'artista_solo', 'coletivo_cultural', 'produtor_cultural'],
          description: 'Exigida na contratação, se você for convocado.',
        },
        {
          id: 'doc-req-alvara-ccmei',
          name: 'Alvará municipal ou CCMEI',
          category: 'juridico',
          mandatory: false,
          appliesToProfiles: ['banda_grupo', 'artista_solo', 'coletivo_cultural', 'produtor_cultural'],
          description: 'Exigido na contratação, se você for convocado. MEI usa o CCMEI.',
        },
      ],
      officialUrl: 'https://www.indaiatuba.sp.gov.br/cultura/arquivos/doc_edital_20250403110746_chamamento-04-25.pdf',
      officialSource: 'Edital real que inspirou o modelo: Chamamento Público 004/2025 (Edital 024/2025), Prefeitura de Indaiatuba, encerrado em 31/07/2026',
      noticeType: 'simulado',
      annualQuarter: 'Q2',
      cyclePeriod: 'Inscrição contínua no edital real (03/04/2025 a 31/07/2026)',
      isFictitiousNotice: FICTITIOUS_NOTICE,
    },

    // 2. MUNICÍPIOS ATÉ 50 MIL HABITANTES (Restrição específica de população) - Aberto (+45 dias)
    {
      id: 'edital-cidades-criativas-pequenas',
      title: 'Prêmio Cidades Criativas — Municípios até 50 mil hab.',
      issuingBody: 'Ministério da Cultura — Política Nacional Aldir Blanc (PNAB)',
      sphere: 'Federal',
      state: 'Nacional',
      maxCityPopulation: 50000,
      eligibleProfiles: ['artista_solo', 'coletivo_cultural', 'banda_grupo'],
      eligibleLegal: ['pf', 'coletivo'],
      artisticArea: 'Patrimônio Cultural',
      grantValue: 30000,
      totalBudgetFormatted: 'R$ 900.000,00 total',
      publishedDate: getPastDateOffset(10),
      deadlineDate: getDateOffset(45), // 45 dias
      summary: 'Destinado exclusivamente a iniciativas culturais originadas em pequenas cidades brasileiras com até 50.000 habitantes.',
      description: 'Premiação direta para mestres populares, contadores de histórias e coletivos de pequenos municípios com foco na preservação das tradições orais e memória local.',
      objective: 'Fortalecer a permanência cultural e a juventude criativa em localidades rurais e pequenas comunas.',
      eligiblePublic: 'Artistas residentes e com atuação contínua comprovada em municípios com população de até 50 mil habitantes pelo Censo.',
      restrictions: [
        'Iniciativas sediadas em capitais ou cidades com mais de 50.000 habitantes.',
        'Empresas de grande porte.',
      ],
      evaluationCriteria: [
        { title: 'Impacto na comunidade de origem', weight: 40, description: 'Relevância para a preservação da identidade cultural local.' },
        { title: 'Trajetória do coletivo ou artista', weight: 35, description: 'Tempo e consistência de dedicação cultural.' },
        { title: 'Plano de compartilhamento comunitário', weight: 25, description: 'Retorno para escolas ou praças do município.' },
      ],
      requiredDocuments: [
        {
          id: 'doc-req-residencia-rural',
          name: 'Comprovante de Residência em Município Elegível',
          category: 'identificacao',
          mandatory: true,
          appliesToProfiles: ['artista_solo', 'coletivo_cultural', 'banda_grupo'],
          description: 'Certidão ou declaração atestando domicílio em cidade de até 50 mil moradores.',
        },
        {
          id: 'doc-req-atuacao-comunitaria',
          name: 'Comprovante de Atuação Cultural Local',
          category: 'artistico',
          mandatory: true,
          appliesToProfiles: ['artista_solo', 'coletivo_cultural', 'banda_grupo'],
          description: 'Reportagens locais, declarações de associações comunitárias ou fotografias datadas.',
        },
      ],
      officialUrl: 'https://www.gov.br/cultura/pt-br/assuntos/aldirblanc',
      officialSource: 'Ministério da Cultura — Diretrizes PNAB Nacional',
      noticeType: 'simulado',
      annualQuarter: 'Q3',
      cyclePeriod: 'Julho a Setembro',
      isFictitiousNotice: FICTITIOUS_NOTICE,
    },

    // 3. EXCLUSIVO MEI OU EMPRESA (CNPJ) #1 - Aberto (+18 dias)
    {
      id: 'edital-producao-audiovisual-empresas',
      title: 'Fundo Setorial Audiovisual: Curtas-Metragens Independentes',
      issuingBody: 'Agência Nacional do Cinema (Ancine) e FSA',
      sphere: 'Federal',
      state: 'Nacional',
      eligibleProfiles: ['produtor_cultural'],
      eligibleLegal: ['mei', 'empresa'],
      artisticArea: 'Audiovisual',
      grantValue: 120000,
      totalBudgetFormatted: 'R$ 3.600.000,00 total',
      publishedDate: getPastDateOffset(30),
      deadlineDate: getDateOffset(18), // 18 dias
      summary: 'Exclusivo para produtoras audiovisuais e MEIs registrados no segmento audiovisual para finalização de curtas de ficção e animação.',
      description: 'Financiamento para pós-produção, edição de som, color grading e acessibilidade comunicacional (Libras e audiodescrição).',
      objective: 'Possibilitar a conclusão técnica de filmes brasileiros inéditos para estreia em mostras nacionais e internacionais.',
      eligiblePublic: 'Pessoas jurídicas com CNAE audiovisual ativo há mais de 12 meses.',
      restrictions: [
        'Pessoas físicas e coletivos sem registro societário ou MEI.',
        'Projetos sem registro de roteiro na Biblioteca Nacional.',
      ],
      evaluationCriteria: [
        { title: 'Roteiro e proposta estética', weight: 40, description: 'Potência narrativa e domínio de linguagem.' },
        { title: 'Capacidade técnica da produtora', weight: 35, description: 'Currículo da equipe de pós-produção.' },
        { title: 'Plano de acessibilidade e distribuição', weight: 25, description: 'Estratégia de festivais e acessibilidade plena.' },
      ],
      requiredDocuments: [
        {
          id: 'doc-req-cnpj',
          name: 'Comprovante de CNPJ ou Certificado de MEI',
          category: 'juridico',
          mandatory: true,
          appliesToProfiles: ['produtor_cultural'],
          description: 'Documento cadastral ativo com CNAE de produção cultural ou audiovisual.',
        },
        {
          id: 'doc-req-cndt',
          name: 'Certidão Negativa de Débitos Trabalhistas (CNDT)',
          category: 'financeiro_fiscal',
          mandatory: true,
          appliesToProfiles: ['produtor_cultural'],
          description: 'Certidão emitida pelo TST dentro do prazo de validade.',
        },
        {
          id: 'doc-req-certidao-federal',
          name: 'Certidão Conjunta de Tributos Federais',
          category: 'financeiro_fiscal',
          mandatory: true,
          appliesToProfiles: ['produtor_cultural'],
          description: 'Certidão da Receita Federal e PGFN.',
        },
      ],
      officialUrl: 'https://www.gov.br/ancine/pt-br',
      officialSource: 'Agência Nacional do Cinema (Ancine) / Sistema FSA',
      noticeType: 'simulado',
      annualQuarter: 'Q2',
      cyclePeriod: 'Maio a Julho',
      isFictitiousNotice: FICTITIOUS_NOTICE,
    },

    // 4. EXCLUSIVO MEI OU EMPRESA (CNPJ) #2 - Aberto (+60 dias)
    {
      id: 'edital-infraestrutura-galpoes-culturais',
      title: 'Edital FICC — Modernização de Espaços Cênicos e Galpões Culturais',
      issuingBody: 'Secretaria Municipal de Cultura e Turismo de Campinas',
      sphere: 'Municipal',
      city: 'Campinas',
      state: 'SP',
      eligibleProfiles: ['produtor_cultural'],
      eligibleLegal: ['mei', 'empresa'],
      artisticArea: 'Teatro',
      grantValue: 80000,
      totalBudgetFormatted: 'R$ 800.000,00 total',
      publishedDate: getPastDateOffset(15),
      deadlineDate: getDateOffset(60), // 60 dias
      summary: 'Destinado a espaços culturais geridos por microempresas ou MEI para reformas de acústica, iluminação cênica e acessibilidade.',
      description: 'Recurso específico para equipamentos teatrais, refletores LED, climatização de salas e melhorias para recepção de plateia PCD.',
      objective: 'Qualificar a infraestrutura técnica de espaços teatrais independentes da Região Metropolitana de Campinas.',
      eligiblePublic: 'Empresas culturais e MEIs com sede no município de Campinas com espaço físico aberto à comunidade há pelo menos 2 anos.',
      restrictions: [
        'Pessoas físicas sem personalidade jurídica.',
        'Espaços públicos geridos diretamente pela prefeitura.',
      ],
      evaluationCriteria: [
        { title: 'Relevância da modernização proposta', weight: 45, description: 'Ganho efetivo de segurança, acústica e acessibilidade.' },
        { title: 'Programação pública oferecida', weight: 35, description: 'Compromisso com sessões a preços populares e contrapartidas.' },
        { title: 'Orçamento detalhado e cotações', weight: 20, description: 'Rigor e precisão nos orçamentos técnicos.' },
      ],
      requiredDocuments: [
        {
          id: 'doc-req-cnpj-campinas',
          name: 'Comprovante de Inscrição e CNPJ Municipal',
          category: 'juridico',
          mandatory: true,
          appliesToProfiles: ['produtor_cultural'],
          description: 'Comprovante da sede com alvará ou contrato de locação do espaço cênico.',
        },
        {
          id: 'doc-req-fgts',
          name: 'Certificado de Regularidade do FGTS',
          category: 'financeiro_fiscal',
          mandatory: true,
          appliesToProfiles: ['produtor_cultural'],
          description: 'CRF Caixa Econômica Federal em dia.',
        },
      ],
      officialUrl: 'https://portal.campinas.sp.gov.br/secretaria/cultura-e-turismo',
      officialSource: 'Fundo de Investimentos Culturais de Campinas (FICC)',
      noticeType: 'simulado',
      annualQuarter: 'Q3',
      cyclePeriod: 'Agosto a Outubro',
      isFictitiousNotice: FICTITIOUS_NOTICE,
    },

    // 5. TEATRO — Aberto (+35 dias, aceita Coletivos sem CNPJ e PF)
    {
      id: 'edital-teatro-montagens-independentes',
      title: 'Prêmio Funarte de Montagens Teatrais Contemporâneas',
      issuingBody: 'Fundação Nacional de Artes (Funarte) — Ministério da Cultura',
      sphere: 'Federal',
      state: 'Nacional',
      eligibleProfiles: ['banda_grupo', 'coletivo_cultural', 'artista_solo'],
      eligibleLegal: ['pf', 'coletivo'],
      artisticArea: 'Teatro',
      grantValue: 55000,
      totalBudgetFormatted: 'R$ 1.100.000,00 total',
      publishedDate: getPastDateOffset(20),
      deadlineDate: getDateOffset(35), // 35 dias
      summary: 'Estímulo à pesquisa cênica, dramaturgia autoral e temporadas teatrais populares para grupos e coletivos independentes.',
      description: 'Apoio à produção, cenografia, figurino e estreia de espetáculos inéditos ou remontagens que debatam a cena brasileira contemporânea.',
      objective: 'Garantir a subsistência de atores e diretores independentes durante a etapa de ensaios e temporada de estreia.',
      eligiblePublic: 'Coletivos cênicos com ou sem CNPJ e artistas solos representados por pessoa física.',
      restrictions: [
        'Obras comerciais com ingressos com valores acima do teto social definido no regulamento.',
      ],
      evaluationCriteria: [
        { title: 'Conceito de encenação e dramaturgia', weight: 40, description: 'Originalidade na abordagem textual e corpo cênico.' },
        { title: 'Histórico artístico do elenco', weight: 30, description: 'Experiência prévia em montagens independentes.' },
        { title: 'Plano de acessibilidade de plateia', weight: 30, description: 'Sessões com interpretação em Libras e debate aberto.' },
      ],
      requiredDocuments: [
        {
          id: 'doc-req-carta-coletivo',
          name: 'Carta de Apresentação e Histórico do Coletivo',
          category: 'juridico',
          mandatory: true,
          appliesToProfiles: ['coletivo_cultural', 'banda_grupo'],
          description: 'Documento assinado com a trajetória cênica e divisão de funções da equipe.',
        },
        {
          id: 'doc-req-direitos-autorais',
          name: 'Autorização de Texto / Direitos Autorais ou Declaração de Domínio Público',
          category: 'artistico',
          mandatory: true,
          appliesToProfiles: ['coletivo_cultural', 'banda_grupo', 'artista_solo'],
          description: 'Autorização do autor ou comprovação de texto autoral ou em domínio público.',
        },
      ],
      officialUrl: 'https://www.gov.br/funarte/pt-br',
      officialSource: 'Fundação Nacional de Artes (Funarte) — Programa Retomada',
      noticeType: 'simulado',
      annualQuarter: 'Q2',
      cyclePeriod: 'Abril a Junho',
      isFictitiousNotice: FICTITIOUS_NOTICE,
    },

    // 6. ARTES VISUAIS — Aberto (+14 dias, Pessoa Física)
    {
      id: 'edital-artes-visuais-residencia',
      title: 'Bolsa de Residência e Pesquisa em Artes Visuais ProAC 2026',
      issuingBody: 'Secretaria da Cultura, Economia e Indústria Criativas de SP',
      sphere: 'Estadual',
      state: 'SP',
      eligibleProfiles: ['artista_solo'],
      eligibleLegal: ['pf'],
      artisticArea: 'Artes Visuais',
      grantValue: 25000,
      totalBudgetFormatted: 'R$ 250.000,00 total (10 bolsas)',
      publishedDate: getPastDateOffset(18),
      deadlineDate: getDateOffset(14), // 14 dias
      summary: 'Bolsa individual de pesquisa poética para artistas visuais, gravuristas, fotógrafos e escultores com exposição coletiva final.',
      description: 'O programa oferece 3 meses de acompanhamento curatorial, verba de produção para compra de materiais e montagem de ateliê aberto.',
      objective: 'Viabilizar a produção material de novas séries artísticas por criadores emergentes do estado.',
      eligiblePublic: 'Artistas visuais maiores de 18 anos inscritos como pessoa física (CPF próprio).',
      restrictions: [
        'Inscrição por pessoa jurídica ou múltiplos autores em projeto individual.',
        'Estudantes de graduação com dedicação exclusiva em bolsa FAPESP/CNPq.',
      ],
      evaluationCriteria: [
        { title: 'Coerência da pesquisa poética', weight: 45, description: 'Rigor investigativo do projeto visual e materiais previstos.' },
        { title: 'Portfólio e trajetória', weight: 35, description: 'Qualidade das séries anteriores e consistência.' },
        { title: 'Memorial descritivo da exposição', weight: 20, description: 'Viabilidade de instalação no espaço físico do museu.' },
      ],
      requiredDocuments: [
        {
          id: 'doc-req-cpf-rg',
          name: 'Documento de Identificação Oficial com CPF',
          category: 'identificacao',
          mandatory: true,
          appliesToProfiles: ['artista_solo'],
          description: 'RG, CNH ou Passaporte digitalizado.',
        },
        {
          id: 'doc-req-portfolio-visual',
          name: 'Portfólio de Obras e Séries Visuais',
          category: 'artistico',
          mandatory: true,
          appliesToProfiles: ['artista_solo'],
          description: 'Documento PDF com até 15 imagens de obras catalogadas e ficha técnica.',
        },
      ],
      officialUrl: 'https://www.proac.sp.gov.br/',
      officialSource: 'Secretaria da Cultura de SP / ProAC Editais',
      noticeType: 'simulado',
      annualQuarter: 'Q1',
      cyclePeriod: 'Março a Maio',
      isFictitiousNotice: FICTITIOUS_NOTICE,
    },

    // 7. MÚSICA #2 — Aberto (+75 dias, Indaiatuba, Coletivos sem CNPJ e PF)
    {
      id: 'edital-orquestras-coros-comunitarios',
      title: 'Circuito de Música Instrumental, Fanfarras e Corais de Indaiatuba',
      issuingBody: 'Prefeitura Municipal de Indaiatuba — Secretaria de Cultura',
      sphere: 'Municipal',
      city: 'Indaiatuba',
      state: 'SP',
      eligibleProfiles: ['banda_grupo', 'coletivo_cultural'],
      eligibleLegal: ['pf', 'coletivo'],
      artisticArea: 'Música',
      grantValue: 35000,
      totalBudgetFormatted: 'R$ 280.000,00 total',
      publishedDate: getPastDateOffset(5),
      deadlineDate: getDateOffset(75), // 75 dias
      summary: 'Apoio a fanfarras juvenis, conjuntos instrumentais e corais populares da comarca de Indaiatuba e bacia do Capivari.',
      description: 'Subsídio para aquisição de palhetas, cordas, partituras e realização de concertos didáticos nas praças e parques de Indaiatuba.',
      objective: 'Preservar a rica tradição musical e filarmônica do interior, incentivando novos músicos em fase de aprendizado.',
      eligiblePublic: 'Grupos musicais com pelo menos 5 integrantes residentes na cidade de Indaiatuba ou região imediata.',
      restrictions: [
        'Projetos com cobrança de ingressos.',
      ],
      evaluationCriteria: [
        { title: 'Caráter comunitário e pedagógico', weight: 40, description: 'Inserção comunitária e oportunidade para jovens instrumentistas.' },
        { title: 'Qualidade do plano de ensaios e concertos', weight: 35, description: 'Locais acessíveis e repertório didático.' },
        { title: 'Relação de custos com instrumentos e insumos', weight: 25, description: 'Economicidade e transparência nos gastos.' },
      ],
      requiredDocuments: [
        {
          id: 'doc-req-membros-indaiatuba',
          name: 'Lista de Músicos Integrantes e Comprovantes Locais',
          category: 'identificacao',
          mandatory: true,
          appliesToProfiles: ['banda_grupo', 'coletivo_cultural'],
          description: 'Relação dos músicos participantes comprovando residência local em Indaiatuba.',
        },
      ],
      officialUrl: 'https://www.indaiatuba.sp.gov.br/cultura/',
      officialSource: 'Prefeitura de Indaiatuba — Departamento de Ações Culturais',
      noticeType: 'simulado',
      annualQuarter: 'Q2',
      cyclePeriod: 'Maio a Julho',
      isFictitiousNotice: FICTITIOUS_NOTICE,
    },

    // 8. DANÇA — Aberto (+21 dias, Pessoa Física)
    {
      id: 'edital-danca-corpo-e-territorio',
      title: 'Prêmio ProAC Dança: Territórios e Movimento Urbano',
      issuingBody: 'Secretaria da Cultura, Economia e Indústria Criativas de SP',
      sphere: 'Estadual',
      state: 'SP',
      eligibleProfiles: ['artista_solo', 'coletivo_cultural'],
      eligibleLegal: ['pf', 'coletivo'],
      artisticArea: 'Dança',
      grantValue: 28000,
      totalBudgetFormatted: 'R$ 420.000,00 total',
      publishedDate: getPastDateOffset(12),
      deadlineDate: getDateOffset(21), // 21 dias
      summary: 'Estímulo a solos de dança contemporânea, danças urbanas (breaking, hip-hop) e expressões afro-brasileiras.',
      description: 'Financiamento para desenvolvimento de coreografias com apresentação em espaços abertos, pistas de skate e centros culturais.',
      objective: 'Fortalecer a cena das danças periféricas e a pesquisa de movimento autoral no estado.',
      eligiblePublic: 'Dançarinos e coreógrafos independentes atuantes há mais de 2 anos.',
      restrictions: ['Eventos de competição com premiação em dinheiro oriunda dos recursos do projeto.'],
      evaluationCriteria: [
        { title: 'Expressividade coreográfica e pesquisa corporal', weight: 40, description: 'Inovação nos movimentos e diálogo com o espaço público.' },
        { title: 'Acessibilidade estética e conexão comunitária', weight: 35, description: 'Capacidade de envolver o público de rua.' },
        { title: 'Cronograma e plano de ensaios', weight: 25, description: 'Planejamento de produção e segurança física dos dançarinos.' },
      ],
      requiredDocuments: [
        {
          id: 'doc-req-video-danca',
          name: 'Link de Registro em Vídeo de Ensaios ou Apresentações',
          category: 'artistico',
          mandatory: true,
          appliesToProfiles: ['artista_solo', 'coletivo_cultural'],
          description: 'Link permanente para gravação em vídeo sem cortes evidenciando técnica.',
        },
      ],
      officialUrl: 'https://www.proac.sp.gov.br/',
      officialSource: 'Secretaria da Cultura de SP / ProAC Editais',
      noticeType: 'simulado',
      annualQuarter: 'Q2',
      cyclePeriod: 'Abril a Maio',
      isFictitiousNotice: FICTITIOUS_NOTICE,
    },

    // 9. LITERATURA — Aberto (+7 dias, Indaiatuba, Pessoa Física, URGENTE)
    {
      id: 'edital-literatura-publicacoes-independentes',
      title: 'Bolsa Criação Literária e Zines: Vozes de Indaiatuba e Região',
      issuingBody: 'Prefeitura Municipal de Indaiatuba — Secretaria de Cultura',
      sphere: 'Municipal',
      city: 'Indaiatuba',
      state: 'SP',
      eligibleProfiles: ['artista_solo'],
      eligibleLegal: ['pf'],
      artisticArea: 'Literatura',
      grantValue: 15000,
      totalBudgetFormatted: 'R$ 150.000,00 total (10 autores)',
      publishedDate: getPastDateOffset(23),
      deadlineDate: getDateOffset(7), // 7 dias (o mais próximo aberto)
      summary: 'Publicação impressa de contos, poesia, dramaturgia e cordel por autores estreantes e independentes.',
      description: 'Concessão de bolsa para tiragem mínima de 300 exemplares com distribuição gratuita em bibliotecas públicas da rede municipal de Indaiatuba.',
      objective: 'Incentivar novos escritores e ampliar o acervo de literatura autoral contemporânea.',
      eligiblePublic: 'Escritores residentes em Indaiatuba inscritos como pessoa física.',
      restrictions: ['Obras já editadas por editoras comerciais com ISBN anterior.'],
      evaluationCriteria: [
        { title: 'Originalidade estilística e literária', weight: 50, description: 'Qualidade do texto poético ou narrativo.' },
        { title: 'Plano de distribuição em bibliotecas e escolas', weight: 30, description: 'Compromisso com o acesso público aos exemplares.' },
        { title: 'Memorial descritivo da publicação', weight: 20, description: 'Especificações gráficas e formato do livro.' },
      ],
      requiredDocuments: [
        {
          id: 'doc-req-manuscrito',
          name: 'Amostra de Manuscrito Inédito (PDF)',
          category: 'artistico',
          mandatory: true,
          appliesToProfiles: ['artista_solo'],
          description: 'Trecho representativo de 10 a 20 páginas da obra a ser impressa.',
        },
      ],
      officialUrl: 'https://www.indaiatuba.sp.gov.br/cultura/',
      officialSource: 'Prefeitura de Indaiatuba — Secretaria Municipal de Cultura',
      noticeType: 'simulado',
      annualQuarter: 'Q1',
      cyclePeriod: 'Fevereiro a Março',
      isFictitiousNotice: FICTITIOUS_NOTICE,
    },

    // 10. CIRCO — Aberto (+88 dias, Coletivos sem CNPJ)
    {
      id: 'edital-circo-itinerante-lonas',
      title: 'Fomento à Arte Circense e Trupes Itinerantes',
      issuingBody: 'Fundação Nacional de Artes (Funarte) e MinC',
      sphere: 'Federal',
      state: 'Nacional',
      eligibleProfiles: ['coletivo_cultural', 'banda_grupo'],
      eligibleLegal: ['pf', 'coletivo', 'mei'],
      artisticArea: 'Circo',
      grantValue: 65000,
      totalBudgetFormatted: 'R$ 1.950.000,00 total',
      publishedDate: getPastDateOffset(1),
      deadlineDate: getDateOffset(88), // 88 dias
      summary: 'Apoio a trupes de palhaçaria, malabares, acrobacia e manutenção de lonas circenses itinerantes.',
      description: 'Recurso para compra de aparelhos de segurança, lona antichamas, som móvel e realização de festivais comunitários de circo.',
      objective: 'Preservar a tradição de famílias e trupes circenses que levam entretenimento popular aos quatro cantos do país.',
      eligiblePublic: 'Trupes familiares e coletivos circenses com itinerância comprovada.',
      restrictions: ['Projetos sem profissional responsável pela segurança de aparelhos de altura.'],
      evaluationCriteria: [
        { title: 'Medidas de segurança cênica e técnica', weight: 35, description: 'Atestados de segurança de aparelhos e rigging.' },
        { title: 'Valor comunitário das apresentações', weight: 35, description: 'Espetáculos gratuitos e abertos a crianças e famílias.' },
        { title: 'Tradição e histórico da trupe', weight: 30, description: 'Anos de atuação e preservação da linguagem circense.' },
      ],
      requiredDocuments: [
        {
          id: 'doc-req-circo-seguranca',
          name: 'Laudo ou Declaração de Segurança dos Aparelhos',
          category: 'juridico',
          mandatory: true,
          appliesToProfiles: ['coletivo_cultural', 'banda_grupo'],
          description: 'Declaração formal assinada atestando inspeção periódica de cabos e mastros.',
        },
      ],
      officialUrl: 'https://www.gov.br/funarte/pt-br',
      officialSource: 'Ministério da Cultura e Funarte',
      noticeType: 'simulado',
      annualQuarter: 'Q4',
      cyclePeriod: 'Outubro a Dezembro',
      isFictitiousNotice: FICTITIOUS_NOTICE,
    },

    // 11. ENCERRADO #1 — Vencido há exatamente 5 dias
    {
      id: 'edital-encerrado-microprojetos-musica',
      title: 'Microprojetos Sonoros: Gravando o Primeiro Single',
      issuingBody: 'Secretaria da Cultura de SP (Ciclo Encerrado)',
      sphere: 'Estadual',
      state: 'SP',
      eligibleProfiles: ['banda_grupo', 'artista_solo'],
      eligibleLegal: ['pf', 'mei'],
      artisticArea: 'Música',
      grantValue: 12000,
      totalBudgetFormatted: 'R$ 240.000,00 total',
      publishedDate: getPastDateOffset(45),
      deadlineDate: getPastDateOffset(5), // Encerrado há 5 dias
      summary: 'Edital de apoio a horas de estúdio para gravação, mixagem e masterização de fonograma de estreia.',
      description: 'Financiamento emergencial para músicos sem gravação profissional lançarem sua primeira faixa em serviços de streaming.',
      objective: 'Propiciar a primeira experiência em estúdio fonográfico de alta fidelidade com produtor profissional.',
      eligiblePublic: 'Músicos com menos de 3 faixas lançadas comercialmente.',
      restrictions: ['Artistas que já possuam contrato fonográfico ativo com gravadoras multinacionais.'],
      evaluationCriteria: [
        { title: 'Potencial criativo da canção demo', weight: 50, description: 'Letra, melodia e mensagem da obra musical.' },
        { title: 'Plano de estúdio e equipe técnica', weight: 50, description: 'Relação do estúdio escolhido e proposta de arranjo.' },
      ],
      requiredDocuments: [
        {
          id: 'doc-req-demo',
          name: 'Gravação Demo em Celular ou MP3',
          category: 'artistico',
          mandatory: true,
          appliesToProfiles: ['banda_grupo', 'artista_solo'],
          description: 'Áudio simples gravado em ensaio ou voz e violão.',
        },
      ],
      officialUrl: 'https://www.proac.sp.gov.br/',
      officialSource: 'Secretaria da Cultura de SP',
      noticeType: 'simulado',
      annualQuarter: 'Q1',
      cyclePeriod: 'Janeiro a Fevereiro',
      isFictitiousNotice: FICTITIOUS_NOTICE,
    },

    // 12. ENCERRADO #2 — Vencido há exatamente 20 dias
    {
      id: 'edital-encerrado-pesquisa-patrimonio',
      title: 'Mapeamento das Raízes Caipiras e Tradições Fluviais',
      issuingBody: 'Instituto do Patrimônio Histórico e Artístico Nacional (IPHAN)',
      sphere: 'Federal',
      state: 'SP',
      eligibleProfiles: ['coletivo_cultural', 'produtor_cultural'],
      eligibleLegal: ['coletivo', 'empresa'],
      artisticArea: 'Patrimônio Cultural',
      grantValue: 50000,
      totalBudgetFormatted: 'R$ 500.000,00 total',
      publishedDate: getPastDateOffset(60),
      deadlineDate: getPastDateOffset(20), // Encerrado há 20 dias
      summary: 'Inventário participativo das festas religiosas, folias de reis e saberes culinários do Médio Tietê.',
      description: 'Registro etnográfico em vídeo e fotografia com depoimentos de mestres artesãos e cozinheiras tradicionais.',
      objective: 'Publicar cartilha educativa e banco digital de registros orais em acesso livre.',
      eligiblePublic: 'Pesquisadores comunitários e coletivos de patrimônio imaterial.',
      restrictions: ['Trabalhos acadêmicos que não prevejam devolução direta das informações às comunidades ouvidas.'],
      evaluationCriteria: [
        { title: 'Metodologia de escuta comunitária', weight: 45, description: 'Ética na pesquisa com idosos e comunidades tradicionais.' },
        { title: 'Plano de arquivamento digital', weight: 35, description: 'Acesso público e gratuito às gravações.' },
        { title: 'Equipe multidisciplinar', weight: 20, description: 'Presença de moradores locais na equipe de campo.' },
      ],
      requiredDocuments: [
        {
          id: 'doc-req-anuencia-comunidade',
          name: 'Termo de Consentimento das Comunidades Mapeadas',
          category: 'juridico',
          mandatory: true,
          appliesToProfiles: ['coletivo_cultural', 'produtor_cultural'],
          description: 'Anuência prévia dos líderes comunitários.',
        },
      ],
      officialUrl: 'https://www.gov.br/iphan/pt-br',
      officialSource: 'IPHAN — Superintendência em São Paulo',
      noticeType: 'simulado',
      annualQuarter: 'Q1',
      cyclePeriod: 'Janeiro a Fevereiro',
      isFictitiousNotice: FICTITIOUS_NOTICE,
    },
  ];
}

/**
 * Helper para verificar o status e dias restantes de um edital
 */
export function getGrantDeadlineInfo(deadlineDateStr: string) {
  const deadline = new Date(deadlineDateStr).getTime();
  const now = Date.now();
  const diffMs = deadline - now;
  const daysDiff = Math.ceil(diffMs / (1000 * 60 * 60 * 24));

  const isClosed = daysDiff < 0;
  return {
    isClosed,
    daysRemaining: isClosed ? Math.abs(daysDiff) : daysDiff,
    label: isClosed 
      ? `Encerrado há ${Math.abs(daysDiff)} dias` 
      : daysDiff === 0 
        ? 'Encerra hoje' 
        : `Encerra em ${daysDiff} dias`,
  };
}
